//! # High-Level Database Interface

const std = @import("std");
const log = std.log;
const mem = std.mem;
const debug = std.debug;
const testing = std.testing;
const ArrayList = std.ArrayList;
const Allocator = mem.Allocator;

const jsonic = @import("jsonic");

const types = @import("./types.zig");

const sqlite3 = @import("../binding/sqlite3.zig");
const STMT = sqlite3.STMT;
const Blob = sqlite3.Blob;
const Flag = sqlite3.OpenFlag;
const Option = sqlite3.Option;
const Database = sqlite3.Database;
const BlobOption = sqlite3.BlobOption;
const ExecResult = sqlite3.ExecResult;

pub const Result = sqlite3.Result;


heap: Allocator,
instance: sqlite3.Database,

const Self = @This();

/// # Initializes SQLite with Global Configuration
pub fn init(opt: Option) !void {
    try sqlite3.config(@intFromEnum(opt));
    try sqlite3.initialize();
}

/// # Destroys SQLite Resources and Configurations
pub fn deinit() void {
    sqlite3.shutdown() catch |err| { log.err("{s}", .{@errorName(err)}); };
}

const Permission = enum { ReadOnly, FileUri, All };

/// # Open or Creates a Database Instance
/// - `filename` - When **null**, creates an in-memory database
/// - `p` - Permission for the given database file:
///     - `ReadOnly` - Expects the file to be available on the file system
///     - `FileUri` - Same as `ReadOnly` with additional URIs at the end
///         - Example on mac: `file:/users/john/demo-file.db?immutable=1`
///         - Example on windows: `file:C:/john/demo-file.db?immutable=1`
///     - `All` - Create the file if not exists with read write permission
pub fn open(heap: Allocator, filename: ?[:0]const u8, p: Permission) !Self {
    const flags = switch (p) {
        .ReadOnly => @intFromEnum(Flag.ReadOnly),
        .FileUri => @intFromEnum(Flag.ReadOnly) | @intFromEnum(Flag.FileUri),
        .All => @intFromEnum(Flag.Create) | @intFromEnum(Flag.ReadWrite)
    };

    const db = if (filename) |file| try sqlite3.openV2(file, flags)
    else try sqlite3.openV2(":memory:", flags);

    return .{.heap = heap, .instance = db};
}

/// # Closes the Database Instance
pub fn close(self: *Self) void { sqlite3.closeV2(self.instance); }

/// # Performs One-Step Query Execution
/// - Convenient wrapper around `prepare()`, `step()`, and `finalize()`
/// - Use only for non-repetitive SQL statements such as creating a table
/// - Avoid when parameter binding or retrieving complex results is required
///
/// **Remarks:**
/// - The callback function receives the results one row at a time
/// - All row data retrieve by the `exec()` is in text representation
/// - In a multiple statement execution, `exec()` does not explicitly tell the
///   callback which statement produced a particular row.
pub fn exec(self: *Self, sql: []const u8) !ExecResult {
    return try sqlite3.exec(self.heap, self.instance, sql);
}

/// # Executes a Statement Discarding Any Retrieved Records
/// **Remarks:** Intended for internal use only
fn execVoid(self: *Self, sql: []const u8) !void {
    var crud = try self.prepare(sql);
    defer crud.destroy();

    _ = try sqlite3.step(crud.stmt);
}

/// # Compiles SQL Text into Byte-Code
/// **Remarks:** SQLite does not cache compiled statements on its own -
/// each call pays the full recompilation cost. Keep the returned `CRUD`
/// alive and re-run its operations to amortize it. see `CRUD.reset()`
pub fn prepare(self: *Self, sql: []const u8) !CRUD {
    const stmt = sqlite3.prepareV3(self.instance, sql) catch |err| {
        log.warn("{s}", .{self.errMsg()});
        return err;
    };
    return CRUD.create(self, stmt);
}

/// # Shows Human-Readable Error Message
/// - Most recent error that occurred on a given database connection
pub fn errMsg(self: *Self) []const u8 {
    return sqlite3.errMsg(self.instance);
}

/// # Provides Database Interactions
/// - Supports single statement query (first one)
/// - In a multi-statement query, other statements are discarded
///
/// **WARNING:** You must call `destroy()` at the end to release the STMT
pub const CRUD = struct {
    db: *Self,
    stmt: STMT,

    /// # Creates the Interface
    /// - **Remarks:** For internal use only, by the `Self.prepare()`
    fn create(db: *Self, stmt: STMT) CRUD {
        return .{.db = db, .stmt = stmt };
    }

    /// # Destroys the Interface
    pub fn destroy(self: *CRUD) void {
        sqlite3.finalize(self.stmt) catch |err| {
            log.err("{s}", .{@errorName(err)});
        };
    }

    /// # Releases the Compiled Statement for Re-execution
    /// - Keeps the compiled byte-code, removing the `prepare()` recompilation
    ///   cost from repeated operations on the same SQL text
    /// - Clears all bound parameters back to their default (**NULL**) state
    ///
    /// **Remarks:** Keep the `CRUD` interface alive and re-run its operations
    /// instead of destroying it - every public operation resets the statement
    /// automatically. Manual invocation is only needed between raw `step()`
    /// calls on `stmt`.
    pub fn reset(self: *CRUD) !void {
        try sqlite3.reset(self.stmt);
        try sqlite3.clearBinding(self.stmt);
    }

    /// # Resets the Statement Ignoring Previous Execution Errors
    /// **Remarks:** Intended for internal use only. `sqlite3_reset()` reports
    /// the most recent step failure, which was already surfaced to the
    /// caller - swallowing it here keeps statement reuse frictionless.
    fn recycle(self: *CRUD) void {
        sqlite3.reset(self.stmt) catch {};
        sqlite3.clearBinding(self.stmt) catch {};
    }

    /// # Frees Up Heap Allocated Memories
    /// - Retrieved by read operations - `readOne()` and `readMany()`
    pub fn free(self: *CRUD, result: anytype) void {
        const T = @TypeOf(result);
        switch (@typeInfo(T)) {
            .@"struct" => {
                release(self.db.heap, result);
            },
            .optional => {
                if (result == null) return;
                release(self.db.heap, result.?);
            },
            .pointer => |p| {
                if (!(p.attrs.@"const" and p.size == .slice)) {
                    @compileError("@quill: Pointer type must be `[]const T`");
                }

                const items: T = result;
                for (0..items.len) |i| release(self.db.heap, items[i]);
                self.db.heap.free(items);
            },
            else => @compileError(
                "@quill: Result must be a struct of - `T`, `?T` or `[]const T`"
            )
        }
    }

    fn release(heap: Allocator, data: anytype) void {
        const T = @TypeOf(data);
        const info = @typeInfo(T).@"struct";
        const err_str = "@quill: Pointer type must be `[]const T`";

        inline for (info.field_names) |f_name| {
            const FT = @FieldType(T, f_name);
            const value = @field(data, f_name);

            switch (@typeInfo(FT)) {
                .@"struct" => jsonic.free(heap, value),
                .optional => |o| {
                    switch (@typeInfo(o.child)) {
                        .@"struct" => if (value) |v| jsonic.free(heap, v),
                        .pointer => |p| {
                            if (!(p.attrs.@"const" and p.size == .slice)) {
                                @compileError(err_str);
                            }

                            if (p.child == u8) {
                                if (value) |v| heap.free(v);
                            } else {
                                if (value) |v| jsonic.free(heap, v);
                            }
                        },
                        else => {}, // NOP
                    }
                },
                .pointer => |p| {
                    if (!(p.attrs.@"const" and p.size == .slice)) {
                        @compileError(err_str);
                    }

                    if (p.child == u8) heap.free(value)
                    else jsonic.free(heap, value);
                },
                else => {} // NO-OP
            }
        }
    }

    /// # Resets the Statement and Binds Filter Params when not **null**
    /// **Remarks:** Intended for internal use only. Resetting prior execution
    /// state allows a prepared statement to be reused without recompiling.
    fn bindFilter(self: *CRUD, filter: anytype) !void {
        self.recycle();

        if (@TypeOf(filter) != @TypeOf(null)) {
            var params = sqlite3.Bind.init(self.db.heap, self.stmt);
            try types.bindFilterData(&params, filter);
        }
    }

    /// # Retrieves a Single (Record) Query Result
    /// **Remarks:** For multiple records only the first one is retrieved
    /// - `T` - Record View structure
    /// - `filter` - **null**, Otherwise instance of an Filter structure
    ///
    /// **WARNING:** Result must be freed by calling `free()`
    pub fn readOne(self: *CRUD, comptime T: type, filter: anytype) !?T {
        try self.bindFilter(filter);

        if (try sqlite3.step(self.stmt) == .Done) return null;

        var column = sqlite3.Column.init(self.db.heap, self.stmt);
        return try types.convertTo(self.db.heap, &column, T);
    }

    /// # Retrieves Multiple (Records) Query Result
    /// **Remarks:** Use this when record limits are known. Otherwise use
    /// the `readOne()` within a while loop for progressive retrieval.
    /// - `T` - Record View structure
    /// - `filter` - **null**, Otherwise instance of an Filter structure
    ///
    /// **WARNING:** Result must be freed by calling `free()`
    pub fn readMany(self: *CRUD, comptime T: type, filter: anytype) ![]const T {
        const heap = self.db.heap;
        try self.bindFilter(filter);

        var records: ArrayList(T) = .empty;
        // Pre-allocates a small chunk to reduce repeated growth reallocations
        try records.ensureTotalCapacity(heap, 16);
        while (try sqlite3.step(self.stmt) == .Row) {
            var column = sqlite3.Column.init(heap, self.stmt);
            try records.append(heap, try types.convertTo(heap, &column, T));
        }

        return try records.toOwnedSlice(heap);
    }

    /// # Returns Total Number of Matching Records
    /// **Remarks:** When filter is `null` total record count is returned
    /// - `filter` - **null**, Otherwise instance of an Filter structure
    pub fn count(self: *CRUD, filter: anytype) !usize {
        try self.bindFilter(filter);

        debug.assert(try sqlite3.step(self.stmt) == .Row);
        const column = sqlite3.Column.init(self.db.heap, self.stmt);

        debug.assert(column.dataType(0) == .Int);
        return @intCast(column.int64(0));
    }

    const ExecCallback = *const fn(result: Result, affected: i64) void;

    /// # Binds Params Data and then Executes a SQL Statement
    /// **Remarks:** Can be used for both creating and updating records
    ///
    /// `callback` - Captures execution result when not **NULL**
    pub fn exec(
        self: *CRUD,
        record: anytype,
        filter: anytype,
        callback: ?ExecCallback
    ) !void {
        const heap = self.db.heap;
        try self.bindFilter(filter);

        var list: ArrayList([]const u8) = .empty;
        defer {
            for (list.items) |item| heap.free(item);
            list.deinit(heap);
        }

        var params = sqlite3.Bind.init(heap, self.stmt);
        try types.convertFrom(heap, &list, &params, record);

        const result = try sqlite3.step(self.stmt);
        const affected = sqlite3.changes64(self.db.instance);
        if (callback) |cb| cb(result, affected);
    }

    /// # Removes Matching Records from the Container
    /// **Remarks:** When filter is `null` all record is removed.
    /// Use `builtins.Container.clear()` instead for vacuuming unused space.
    /// - `filter` - **null**, Otherwise instance of an Filter structure
    ///
    /// `callback` - Captures remove result when not **NULL**
    pub fn remove(self: *CRUD, filter: anytype, callback: ?ExecCallback) !void {
        try self.bindFilter(filter);

        const result = try sqlite3.step(self.stmt);
        const affected = sqlite3.changes64(self.db.instance);
        if (callback) |cb| cb(result, affected);
    }
};

/// # Provides Atomic Transaction
pub const AcidSession = struct {
    const Action = enum { Commit, Rollback };
    const Callback = *const fn(result: ExecResult) void;

    /// # Starts ACID Session for Multiple Transaction
    /// - `self` - A database instance (`*Quill`)
    /// - `callback` - Captures execution result when not **NULL**
    pub fn start(self: *Self, callback: ?Callback) !void {
        if (callback) |cb| {
            cb(try self.exec("BEGIN TRANSACTION;"));
        } else {
            try self.execVoid("BEGIN TRANSACTION;");
        }
    }

    /// # Ends ACID Session for Multiple Transaction
    /// - `self` - A database instance (`*Quill`)
    /// - `callback` - Captures execution result when not **NULL**
    pub fn end(self: *Self, act: Action, callback: ?Callback) !void {
        const sql: []const u8 = switch (act) {
            .Commit => "COMMIT;",
            .Rollback => "ROLLBACK;"
        };

        if (callback) |cb| cb(try self.exec(sql))
        else try self.execVoid(sql);
    }
};

/// # Provides Stream Interface for SQLite Blob Data
pub const BlobStream = struct {
    const Error = error { BufferIsTooLong };

    db: *Self,
    blob: Blob,
    length: usize,
    cursor: usize = 0,

    /// # Opens a Stream Interface
    /// - `container` - Container name e.g., `users`, `accounts` etc.
    /// - `field` - Field name e.g., `img_data`, `vid_data` etc.
    /// - `rowid` - Primary Key of a given Record
    /// - `opt` - Read-write permission on the blob data
    ///
    /// **Remarks:** Given container must have implicit `rowid` as Primary Key
    pub fn open(
        db: *Self,
        container: [:0]const u8,
        field: [:0]const u8,
        rowid: i64,
        opt: BlobOption,
    ) !BlobStream {
        const dbi = db.instance;
        const handle = try sqlite3.blobOpen(dbi, container, field, rowid, opt);
        const length: usize = @intCast(sqlite3.blobBytes(handle));

        return .{.db = db, .blob = handle, .length = length};
    }

    /// # Closes the Stream Interface
    pub fn close(self: *BlobStream) void {
        sqlite3.blobClose(self.blob) catch |err| {
            log.err("{s}", .{@errorName(err)});
        };
    }

    /// # Reads Blob Data as Chunked Slice
    pub fn read(self: *BlobStream, buff: []u8) !?[]const u8 {
        const remaining = self.length - self.cursor;
        const len = if (remaining >= buff.len) buff.len else remaining;

        if (len == 0) return null;

        const data = try sqlite3.blobRead(
            self.blob, buff, @intCast(len), @intCast(self.cursor)
        );
        self.cursor += len;
        return data;
    }

    /// # Writes Blob Data at a Given Offset Position
    /// **Remarks:** Only modify the contents of the Blob. The overall Blob size
    /// can't be increased or decreased. Also, `open()` must be called with opt
    /// `.ReadWrite` otherwise error **Locked** will be returned.
    ///
    /// - `buff` - Buffer data to be overwritten on the record.
    /// - `offset` - Offset position to start writing the data.
    pub fn write(self: *BlobStream, buff: []const u8, offset: usize) !void {
        debug.assert(offset < self.length);
        const available = self.length - offset;

        if (available < buff.len) return Error.BufferIsTooLong;
        try sqlite3.blobWrite(
            self.blob, buff, @intCast(buff.len), @intCast(offset)
        );
    }

    /// # Returns the Total Blob Size in Bytes
    pub fn size(self: *BlobStream) usize {
        return @intCast(sqlite3.blobBytes(self.blob));
    }
};

//##############################################################################
//# TESTS ---------------------------------------------------------------------#
//##############################################################################

test "crud statement reuse" {
    try Self.init(.SingleThreaded);
    defer Self.deinit();

    const heap = testing.allocator;
    var db = try Self.open(heap, null, .All);
    defer db.close();

    var setup = try db.exec("CREATE TABLE users (id INTEGER, name TEXT);");
    defer setup.destroy();

    const Dt = types.DataType;
    const Rec = struct { name: Dt.CastInto(.Text, Dt.Slice) };
    const View = struct { id: Dt.Int, name: Dt.Slice };
    const Flt = struct { name: Dt.Slice };

    // One prepared insert, executed repeatedly without recompilation
    var crud = try db.prepare("INSERT INTO users (name) VALUES (:name);");
    defer crud.destroy();

    try crud.exec(Rec{ .name = .{.text = "alice"} }, null, null);
    try crud.exec(Rec{ .name = .{.text = "bob"} }, null, null);

    // One prepared read, executed repeatedly with different filters
    var query = try db.prepare("SELECT id, name FROM users WHERE name = :_name_;");
    defer query.destroy();

    const first = try query.readOne(View, Flt{ .name = "alice" });
    try testing.expect(first != null);
    try testing.expectEqualStrings("alice", first.?.name);
    query.free(first);

    const second = try query.readOne(View, Flt{ .name = "bob" });
    try testing.expect(second != null);
    try testing.expectEqualStrings("bob", second.?.name);
    query.free(second);

    // Manual reset keeps the compiled statement ready for the next run
    try query.reset();
    const again = try query.readOne(View, Flt{ .name = "alice" });
    try testing.expect(again != null);
    query.free(again);

    var counter = try db.prepare("SELECT COUNT(*) FROM users;");
    defer counter.destroy();
    try testing.expectEqual(@as(usize, 2), try counter.count(null));
}
